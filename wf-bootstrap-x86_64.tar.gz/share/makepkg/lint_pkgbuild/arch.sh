#!/bin/bash
#
#   arch.sh - Check the 'arch' array conforms to requirements.
#
#   Copyright (c) 2014-2025 Pacman Development Team <pacman-dev@lists.archlinux.org>
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

[[ -n "$LIBMAKEPKG_LINT_PKGBUILD_ARCH_SH" ]] && return
LIBMAKEPKG_LINT_PKGBUILD_ARCH_SH=1

MAKEPKG_LIBRARY=${MAKEPKG_LIBRARY:-'/opt/wonderful/share/makepkg'}

source "$MAKEPKG_LIBRARY/util/message.sh"
source "$MAKEPKG_LIBRARY/util/pkgbuild.sh"


lint_pkgbuild_functions+=('lint_arch')


validate_arch_entries() {
	local arch=("$@")

	if in_array "any" "${arch[@]}"; then
		if (( ${#arch[@]} != 1 )); then
			error "$(gettext "Can not use '%s' architecture with other architectures")" "any"
			ret=1
		fi
	fi

	if (( ${#arch[@]} != $(printf "%s\n" ${arch[@]} | sort -u | wc -l) )); then
		error "$(gettext "%s can not contain duplicate values")" 'arch'
		ret=1
	fi

	for a in "${arch[@]}"; do
		if [[ $a = *[![:alnum:]_]* ]]; then
			error "$(gettext "%s contains invalid characters: '%s'")" \
					'arch' "${a//[[:alnum:]_]}"
			ret=1
		fi
	done
}

validate_arch_global() {
	if (( ${#arch[@]} == 0 )); then
		error "$(gettext "%s is not allowed to be empty.")" "arch"
		return 1
	fi

	validate_arch_entries "${arch[@]}"

	if (( ! IGNOREARCH )) && ! in_array "$CARCH" "${arch[@]}" && ! in_array "any" "${arch[@]}"; then
		error "$(gettext "%s is not available for the '%s' architecture.")" "$pkgbase" "$CARCH"
		ret=1
	fi

	return $ret
}

validate_arch_override() {
	local package="$1"
	local override

	get_pkgbuild_attribute "$package" 'arch' 1 override

	if (( ${#override[@]} == 0 )); then
		return 0
	fi

	validate_arch_entries "${override[@]}"

	if in_array "any" "${override[@]}"; then
		return $ret
	fi

	for o in "${override[@]}"; do
		if ! in_array "$o" "${arch[@]}"; then
			error "$(gettext "Overridden %s in package_%s() contains value not in global directive: '%s'")" "arch" "$package" "$o"
			ret=1
		fi
	done

	return $ret
}

lint_arch() {
	local name ret=0

	validate_arch_global

	if (( ret == 0 )); then
		for name in "${pkgname[@]}"; do
			validate_arch_override "$name"
		done
	fi

	return $ret
}
