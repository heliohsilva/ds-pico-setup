#!/bin/bash
#
#   util.sh - utility functions for makepkg
#
#   Copyright (c) 2015-2025 Pacman Development Team <pacman-dev@lists.archlinux.org>
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

[[ -n "$LIBMAKEPKG_UTIL_SH" ]] && return
LIBMAKEPKG_UTIL_SH=1

MAKEPKG_LIBRARY=${MAKEPKG_LIBRARY:-'/opt/wonderful/share/makepkg'}

for lib in "$MAKEPKG_LIBRARY/util/"*.sh; do
	source "$lib"
done
